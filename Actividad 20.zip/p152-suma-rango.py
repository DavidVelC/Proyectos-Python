#p152-suma-rango.py
def suma_rango(inicio: int, fin: int) -> int:
    suma = 0
    for i in range(inicio, fin + 1):
        suma += i
    return suma
def main() -> None:
    inicio = int(input("Introduce el inicio del rango: "))
    fin = int(input("Introduce el fin del rango: "))
    if inicio > fin:
        print("El inicio no puede ser mayor que el fin.")
        return
    resultado = suma_rango(inicio, fin)
    print(f"La suma de los números en el rango de {inicio} a {fin} es {resultado}")

if __name__ == "__main__":
    main()